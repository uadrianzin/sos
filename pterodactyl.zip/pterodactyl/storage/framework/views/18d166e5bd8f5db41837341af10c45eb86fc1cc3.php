<?php $__env->startSection('title'); ?>
    <?php echo e(trans('server.index.title', [ 'name' => $server->name])); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
    <?php echo Theme::css('css/terminal.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.index.header'); ?><small><?php echo app('translator')->getFromJson('server.index.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.servers'); ?></a></li>
        <li class="active"><?php echo e($server->name); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-body position-relative">
                <div id="terminal" style="width:100%;"></div>
                <div id="terminal_input" class="form-group no-margin">
                    <div class="input-group">
                        <div class="input-group-addon terminal_input--prompt">container:~/$</div>
                        <input type="text" class="form-control terminal_input--input">
                    </div>
                </div>
                <div id="terminalNotify" class="terminal-notify hidden">
                    <i class="fa fa-bell"></i>
                </div>
            </div>
            <div class="box-footer text-center">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('power-start', $server)): ?><button class="btn btn-success disabled" data-attr="power" data-action="start">Start</button><?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('power-restart', $server)): ?><button class="btn btn-primary disabled" data-attr="power" data-action="restart">Restart</button><?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('power-stop', $server)): ?><button class="btn btn-danger disabled" data-attr="power" data-action="stop">Stop</button><?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('power-kill', $server)): ?><button class="btn btn-danger disabled" data-attr="power" data-action="kill">Kill</button><?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Memory Usage</h3>
            </div>
            <div class="box-body">
                <canvas id="chart_memory" style="max-height:300px;"></canvas>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">CPU Usage</h3>
            </div>
            <div class="box-body">
                <canvas id="chart_cpu" style="max-height:300px;"></canvas>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('vendor/ansi/ansi_up.js'); ?>

    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <?php echo Theme::js('vendor/mousewheel/jquery.mousewheel-min.js'); ?>

    <?php echo Theme::js('js/frontend/console.js'); ?>

    <?php echo Theme::js('vendor/chartjs/chart.min.js'); ?>

    <?php echo Theme::js('vendor/jquery/date-format.min.js'); ?>

    <?php if($server->nest->name === 'Minecraft' && $server->nest->author === 'support@pterodactyl.io'): ?>
        <?php echo Theme::js('js/plugins/minecraft/eula.js'); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>