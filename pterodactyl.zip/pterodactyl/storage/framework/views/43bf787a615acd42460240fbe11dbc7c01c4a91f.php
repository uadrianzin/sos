<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.startup.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.startup.header'); ?><small><?php echo app('translator')->getFromJson('server.config.startup.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.startup_parameters'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.config.startup.command'); ?></h3>
            </div>
            <div class="box-body">
                <div class="form-group no-margin-bottom">
                    <input type="text" class="form-control" readonly value="<?php echo e($startup); ?>" />
                </div>
            </div>
        </div>
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-startup', $server)): ?>
        <form action="<?php echo e(route('server.settings.startup', $server->uuidShort)); ?>" method="POST">
            <?php $__currentLoopData = $variables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-md-4 col-sm-6">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($v->name); ?></h3>
                        </div>
                        <div class="box-body">
                            <input
                                <?php if($v->user_editable): ?>
                                    name="environment[<?php echo e($v->env_variable); ?>]"
                                <?php else: ?>
                                    readonly
                                <?php endif; ?>
                            class="form-control" type="text" value="<?php echo e(old('environment.' . $v->env_variable, $server_values[$v->env_variable])); ?>" />
                            <p class="small text-muted"><?php echo e($v->description); ?></p>
                            <p class="no-margin">
                                <?php if($v->required && $v->user_editable ): ?>
                                    <span class="label label-danger"><?php echo app('translator')->getFromJson('strings.required'); ?></span>
                                <?php elseif(! $v->required && $v->user_editable): ?>
                                    <span class="label label-default"><?php echo app('translator')->getFromJson('strings.optional'); ?></span>
                                <?php endif; ?>
                                <?php if(! $v->user_editable): ?>
                                    <span class="label label-warning"><?php echo app('translator')->getFromJson('strings.read_only'); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="box-footer">
                            <p class="no-margin text-muted small"><strong><?php echo app('translator')->getFromJson('server.config.startup.startup_regex'); ?>:</strong> <code><?php echo e($v->rules); ?></code></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12">
                <div class="box box-primary">
                    <div class="box-footer">
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('PATCH'); ?>

                        <input type="submit" class="btn btn-primary btn-sm pull-right" value="<?php echo app('translator')->getFromJson('server.config.startup.update'); ?>" />
                    </div>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>