<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.schedule.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.schedule.header'); ?><small><?php echo app('translator')->getFromJson('server.schedule.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.schedules'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('server.schedule.current'); ?></h3>
                <div class="box-tools">
                    <a href="<?php echo e(route('server.schedules.new', $server->uuidShort)); ?>"><button class="btn btn-primary btn-sm">Create New</button></a>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('strings.name'); ?></th>
                            <th class="text-center"><?php echo app('translator')->getFromJson('strings.queued'); ?></th>
                            <th class="text-center"><?php echo app('translator')->getFromJson('strings.tasks'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.last_run'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.next_run'); ?></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr <?php if(! $schedule->is_active): ?>class="muted muted-hover"<?php endif; ?>>
                                <td class="middle">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-schedule', $server)): ?>
                                        <a href="<?php echo e(route('server.schedules.view', ['server' => $server->uuidShort, '$schedule' => $schedule->hashid])); ?>">
                                            <?php echo e($schedule->name ?? trans('server.schedule.unnamed')); ?>

                                        </a>
                                    <?php else: ?>
                                        <?php echo e($schedule->name ?? trans('server.schedule.unnamed')); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="middle text-center">
                                    <?php if($schedule->is_processing): ?>
                                        <span class="label label-success"><?php echo app('translator')->getFromJson('strings.yes'); ?></span>
                                    <?php else: ?>
                                        <span class="label label-default"><?php echo app('translator')->getFromJson('strings.no'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="middle text-center"><span class="label label-primary"><?php echo e($schedule->tasks_count); ?></span></td>
                                <td class="middle">
                                <?php if($schedule->last_run_at): ?>
                                    <?php echo e(Carbon::parse($schedule->last_run_at)->toDayDateTimeString()); ?><br /><span class="text-muted small">(<?php echo e(Carbon::parse($schedule->last_run_at)->diffForHumans()); ?>)</span>
                                <?php else: ?>
                                    <em class="text-muted"><?php echo app('translator')->getFromJson('strings.not_run_yet'); ?></em>
                                <?php endif; ?>
                                </td>
                                <td class="middle">
                                    <?php if($schedule->is_active): ?>
                                        <?php echo e(Carbon::parse($schedule->next_run_at)->toDayDateTimeString()); ?><br /><span class="text-muted small">(<?php echo e(Carbon::parse($schedule->next_run_at)->diffForHumans()); ?>)</span>
                                    <?php else: ?>
                                        <em>n/a</em>
                                    <?php endif; ?>
                                </td>
                                <td class="middle">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-schedule', $server)): ?>
                                        <a class="btn btn-xs btn-danger" href="#" data-action="delete-schedule" data-schedule-id="<?php echo e($schedule->hashid); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('strings.delete'); ?>"><i class="fa fa-fw fa-trash-o"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('toggle-schedule', $server)): ?>
                                        <a class="btn btn-xs btn-default" href="#" data-action="toggle-schedule" data-active="<?php echo e($schedule->active); ?>" data-schedule-id="<?php echo e($schedule->hashid); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('server.schedule.toggle'); ?>"><i class="fa fa-fw fa-eye-slash"></i></a>
                                        <a class="btn btn-xs btn-default" href="#" data-action="trigger-schedule" data-schedule-id="<?php echo e($schedule->hashid); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('server.schedule.run_now'); ?>"><i class="fa fa-fw fa-refresh"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <?php echo Theme::js('js/frontend/tasks/management-actions.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>