<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.sftp.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.sftp.header'); ?><small><?php echo app('translator')->getFromJson('server.config.sftp.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.sftp_settings'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('Detalhes FTP'); ?></h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                    <label class="control-label"><?php echo app('translator')->getFromJson('Arquivos via SFTP'); ?></label>
                    <div>
                        <input type="text" class="form-control" readonly value="PARA ANDROID <?php echo e($node->fqdn); ?>:<?php echo e($node->daemonSFTP); ?>" />
                <input type="text" class="form-control" readonly value="PARA PC sftp://<?php echo e($node->fqdn); ?>:<?php echo e($node->daemonSFTP); ?>" /> 
 </div>
                <div class="form-group">
                    <label for="password" class="control-label"><?php echo app('translator')->getFromJson('strings.username'); ?></label>
                    <div>
                        <input type="text" class="form-control" readonly value="<?php echo e(auth()->user()->username); ?>.<?php echo e($server->uuidShort); ?>" />
                    </div>
                </div>
            </div>
            <div>
                <h3 class="small text-muted no-margin-bottom"><?php echo app('translator')->getFromJson('A SENHA É A MESMA DO SEU LOGIN NO PAINEL.                           AVISO PARA QUEM USA ANDROID EXEMPLO PARA CONECTAR O SFTP INSTALE O PROGRAMA ES FILE EXPLORER PRIMEIRO VEM O IP DEPOIS, PORTA EXEMPLO IP:PORTA NO CASO 10.0.0.1:2022 NO CASO, IP Ê 10.0.0.1 E PORTA 2022!'); ?></h3>
              </div>
<div> 
<h3>ABAIXO ESTÁ O DOWNLOAND DO ES FILE EXPLORER</h3>
 <a href="https://es-file-explorer.br.uptodown.com/android">DOWNLOAND</a>    

 </div>
       
<div>

<h3>ABAIXO ESTÁ O DOWNLOAND DO FILEZILA PARA PC</h3>

 <a href="https://filezilla-project.org/download.php?platform=win64">DOWNLOAND</a>



 </div>



 </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>