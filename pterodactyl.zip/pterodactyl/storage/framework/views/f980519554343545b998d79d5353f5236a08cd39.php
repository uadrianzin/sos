<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.schedule.new.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <?php echo Theme::css('vendor/select2/select2.min.css'); ?>

    ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.schedule.new.header'); ?><small><?php echo app('translator')->getFromJson('server.schedule.new.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><a href="<?php echo e(route('server.schedules', $server->uuidShort)); ?>"><?php echo app('translator')->getFromJson('navigation.server.schedules'); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('server.schedule.new.header'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('server.schedules.new', $server->uuidShort)); ?>" method="POST">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo app('translator')->getFromJson('server.schedule.setup'); ?></h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="form-group col-xs-12">
                            <label class="control-label" for="scheduleName"><?php echo app('translator')->getFromJson('strings.name'); ?> <span class="field-optional"></span></label>
                            <div>
                                <input type="text" name="name" id="scheduleName" class="form-control" value="<?php echo e(old('name')); ?>" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group">
                                <label for="scheduleDayOfWeek" class="control-label"><?php echo app('translator')->getFromJson('server.schedule.day_of_week'); ?></label>
                                <div>
                                    <select data-action="update-field" data-field="cron_day_of_week" class="form-control" multiple>
                                        <option value="0"><?php echo app('translator')->getFromJson('strings.days.sun'); ?></option>
                                        <option value="1"><?php echo app('translator')->getFromJson('strings.days.mon'); ?></option>
                                        <option value="2"><?php echo app('translator')->getFromJson('strings.days.tues'); ?></option>
                                        <option value="3"><?php echo app('translator')->getFromJson('strings.days.wed'); ?></option>
                                        <option value="4"><?php echo app('translator')->getFromJson('strings.days.thurs'); ?></option>
                                        <option value="5"><?php echo app('translator')->getFromJson('strings.days.fri'); ?></option>
                                        <option value="6"><?php echo app('translator')->getFromJson('strings.days.sat'); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" id="scheduleDayOfWeek" class="form-control" name="cron_day_of_week" value="<?php echo e(old('cron_day_of_week')); ?>" />
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group">
                                <label for="scheduleDayOfMonth" class="control-label"><?php echo app('translator')->getFromJson('server.schedule.day_of_month'); ?></label>
                                <div>
                                    <select data-action="update-field" data-field="cron_day_of_month" class="form-control" multiple>
                                        <?php $__currentLoopData = range(1, 31); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" id="scheduleDayOfMonth" class="form-control" name="cron_day_of_month" value="<?php echo e(old('cron_day_of_month')); ?>" />
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group col-md-12">
                                <label for="scheduleHour" class="control-label"><?php echo app('translator')->getFromJson('server.schedule.hour'); ?></label>
                                <div>
                                    <select data-action="update-field" data-field="cron_hour" class="form-control" multiple>
                                        <?php $__currentLoopData = range(0, 23); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT)); ?>:00</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-md-12">
                                <input type="text" id="scheduleHour" class="form-control" name="cron_hour" value="<?php echo e(old('cron_hour')); ?>" />
                            </div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <div class="form-group">
                                <label for="scheduleMinute" class="control-label"><?php echo app('translator')->getFromJson('server.schedule.minute'); ?></label>
                                <div>
                                    <select data-action="update-field" data-field="cron_minute" class="form-control" multiple>
                                        <?php $__currentLoopData = range(0, 55); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($i % 5 === 0): ?>
                                                <option value="<?php echo e($i); ?>">_ _:<?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT)); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" id="scheduleMinute" class="form-control" name="cron_minute" value="<?php echo e(old('cron_minute')); ?>" />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer with-border">
                    <p class="small text-muted no-margin-bottom"><?php echo app('translator')->getFromJson('server.schedule.time_help'); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary" id="containsTaskList">
                <?php echo $__env->make('partials.schedules.task-template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="box-footer with-border" id="taskAppendBefore">
                    <div>
                        <p class="text-muted small"><?php echo app('translator')->getFromJson('server.schedule.task_help'); ?></p>
                    </div>
                    <div class="pull-right">
                        <?php echo csrf_field(); ?>

                        <button type="button" class="btn btn-sm btn-default" data-action="add-new-task"><i class="fa fa-plus"></i> <?php echo app('translator')->getFromJson('server.schedule.task.add_more'); ?></button>
                        <button type="submit" class="btn btn-sm btn-success"><?php echo app('translator')->getFromJson('server.schedule.new.submit'); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

    <?php echo Theme::js('vendor/select2/select2.full.min.js'); ?>

    <?php echo Theme::js('js/frontend/tasks/view-actions.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>