<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('server.config.name.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('server.config.name.header'); ?><small><?php echo app('translator')->getFromJson('server.config.name.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><?php echo e($server->name); ?></a></li>
        <li><?php echo app('translator')->getFromJson('navigation.server.configuration'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.server.server_name'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <form action="<?php echo e(route('server.settings.name', $server->uuidShort)); ?>" method="POST">
                <div class="box">
                    <div class="box-body">
                        <div class="form-group no-margin-bottom">
                            <label class="control-label" for="pServerName"><?php echo app('translator')->getFromJson('server.config.name.header'); ?></label>
                            <div>
                                <input type="text" name="name" id="pServerName" class="form-control" value="<?php echo e($server->name); ?>" />
                                <p class="small text-muted no-margin-bottom"><?php echo app('translator')->getFromJson('server.config.name.details'); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <?php echo e(method_field('PATCH')); ?>

                        <?php echo e(csrf_field()); ?>

                        <input type="submit" class="btn btn-sm btn-primary pull-right" value="<?php echo app('translator')->getFromJson('strings.submit'); ?>" />
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <?php echo Theme::js('js/frontend/server.socket.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>